import React, { memo } from 'react'

const Donate = memo(() => {
  return (
    <>
    <h1>Hellow</h1>
    <img src={'../assets/qrcode.jpeg'}  alt="" />
    </>
  )
})

export default Donate