import React, { memo } from 'react'

const doctor = memo(() => {


    //connect html in tailw
    
    return (
        <>

        <h1 className='text-center text-success'>Doctor js</h1>

            
        </>
    )
})

export default doctor


