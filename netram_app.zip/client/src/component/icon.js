import React, { memo } from 'react'

const icon = memo(() => {
  return (
    <>
                    
    </>
  )
})

export default icon